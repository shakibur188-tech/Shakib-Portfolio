/**
 * Md. Shakibur Rahaman - 360° Creative Director & Digital Architect
 * CYBER NOIR & NEON EMERALD ENGINE
 * High-performance ambient canvas background, scroll reveals & hover animations
 */

let dynamicContent = null;
let currentTypewriterTitles = [
  'Brand Strategy & Corporate Identity Architecture',
  'Graphics Design & Visual Systems',
  'High-Performance Web Design & Full-Stack Development',
  'Data-Driven Social Media Marketing (SMM)',
  'Commercial Photoshoot & Cinematic Videography',
  'Experiential Event Activation & 3D Exhibitions',
  'High-Conversion Google Ads & Performance Max',
  'SEO & Generative AI Engine Optimization (AEO)',
  'Strategic Public Relations (PR) & Mainstream Media'
];

let currentModalService = null;

document.addEventListener('DOMContentLoaded', async () => {
  // 1. Initialize Full-Page Ambient Background Animation
  initAmbientBackground();

  // 2. Fetch dynamic CMS content & Hydrate SEO & All Sections
  await fetchAndHydrateContent();

  // 3. Initialize Interactive Features & Motion Engines
  initTypewriter();
  initMobileMenu();
  initProjectFilter();
  initServiceModal();
  initContactForm();
  initScrollEffects();
  initSpotlightCards();
  initScrollReveal();
});

/* ==========================================================================
   0. AMBIENT BACKGROUND ANIMATION CANVAS ENGINE
   Draws soft floating glowing nebula orbs + stardust with gentle mouse parallax
   ========================================================================== */
function initAmbientBackground() {
  const canvas = document.getElementById('ambientCanvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  let width = (canvas.width = window.innerWidth);
  let height = (canvas.height = window.innerHeight);

  let mouse = { x: width / 2, y: height / 2, targetX: width / 2, targetY: height / 2 };

  window.addEventListener('resize', () => {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  }, { passive: true });

  window.addEventListener('mousemove', (e) => {
    mouse.targetX = e.clientX;
    mouse.targetY = e.clientY;
  }, { passive: true });

  // Floating Nebula Orbs
  const orbs = [
    { x: width * 0.2, y: height * 0.25, r: 280, color: 'rgba(0, 245, 155, 0.12)', vx: 0.25, vy: 0.18, phase: 0 },
    { x: width * 0.8, y: height * 0.35, r: 340, color: 'rgba(56, 189, 248, 0.08)', vx: -0.22, vy: 0.15, phase: 2 },
    { x: width * 0.45, y: height * 0.75, r: 300, color: 'rgba(16, 185, 129, 0.10)', vx: 0.18, vy: -0.2, phase: 4 },
    { x: width * 0.85, y: height * 0.85, r: 260, color: 'rgba(0, 245, 155, 0.07)', vx: -0.15, vy: -0.15, phase: 1 }
  ];

  // Stardust Constellation Particles
  const particleCount = Math.min(width > 768 ? 45 : 22, 50);
  const particles = [];
  for (let i = 0; i < particleCount; i++) {
    particles.push({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 1.8 + 0.6,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3 - 0.1,
      alpha: Math.random() * 0.6 + 0.2,
      baseAlpha: Math.random() * 0.6 + 0.2
    });
  }

  let isRunning = true;
  document.addEventListener('visibilitychange', () => {
    isRunning = !document.hidden;
    if (isRunning) requestAnimationFrame(render);
  });

  function render() {
    if (!isRunning) return;

    // Smooth mouse interpolation
    mouse.x += (mouse.targetX - mouse.x) * 0.04;
    mouse.y += (mouse.targetY - mouse.y) * 0.04;

    ctx.clearRect(0, 0, width, height);

    // 1. Draw Nebula Orbs with soft radial blur
    orbs.forEach(orb => {
      orb.phase += 0.008;
      orb.x += orb.vx + Math.sin(orb.phase) * 0.2;
      orb.y += orb.vy + Math.cos(orb.phase) * 0.2;

      // Wrap around bounds
      if (orb.x < -orb.r) orb.x = width + orb.r;
      if (orb.x > width + orb.r) orb.x = -orb.r;
      if (orb.y < -orb.r) orb.y = height + orb.r;
      if (orb.y > height + orb.r) orb.y = -orb.r;

      // Parallax shift toward mouse
      const parallaxX = (mouse.x - width / 2) * 0.03;
      const parallaxY = (mouse.y - height / 2) * 0.03;

      const grad = ctx.createRadialGradient(
        orb.x + parallaxX, orb.y + parallaxY, 0,
        orb.x + parallaxX, orb.y + parallaxY, orb.r
      );
      grad.addColorStop(0, orb.color);
      grad.addColorStop(1, 'transparent');

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(orb.x + parallaxX, orb.y + parallaxY, orb.r, 0, Math.PI * 2);
      ctx.fill();
    });

    // 2. Draw & Update Stardust Particles
    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;

      if (p.x < 0) p.x = width;
      if (p.x > width) p.x = 0;
      if (p.y < 0) p.y = height;
      if (p.y > height) p.y = 0;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(0, 245, 155, ${p.alpha})`;
      ctx.fill();
    });

    requestAnimationFrame(render);
  }

  requestAnimationFrame(render);
}

/* ==========================================================================
   1. Dynamic CMS Content Hydration & Global SEO Engine
   ========================================================================== */
async function fetchAndHydrateContent() {
  try {
    let res = null;
    try {
      res = await fetch('/api/content?t=' + Date.now(), { cache: 'no-store' });
    } catch (e) {
      console.warn('Backend fetch failed, attempting local fallback:', e.message);
    }

    if (res && res.ok) {
      dynamicContent = await res.json();
      try { localStorage.setItem('shakibur_content', JSON.stringify(dynamicContent)); } catch (e) {}
    } else {
      const cached = localStorage.getItem('shakibur_content');
      if (cached) {
        dynamicContent = JSON.parse(cached);
      }
    }

    if (!dynamicContent) return;

    // A. Dynamic SEO Engine Hydration
    if (dynamicContent.seo) {
      hydrateSeoMetadata(dynamicContent.seo);
    }

    // B. Hydrate Profile / Bio / Hero
    if (dynamicContent.profile) {
      const p = dynamicContent.profile;
      const bioEl = document.getElementById('heroBio');
      if (bioEl && p.bio) bioEl.textContent = p.bio;

      const statusBadgeEl = document.getElementById('heroStatusBadge');
      if (statusBadgeEl && p.statusBadge) statusBadgeEl.textContent = p.statusBadge;

      const navNameEl = document.getElementById('navBrandName');
      if (navNameEl && p.name) navNameEl.textContent = p.name;

      if (p.whatsapp) {
        document.querySelectorAll('a[href*="wa.me"]').forEach(a => {
          a.href = `https://wa.me/${p.whatsapp.replace(/\D/g, '')}?text=Hi%20Shakibur,%20I%20would%20like%20to%20discuss%20a%20project.`;
        });
      }
      if (p.email) {
        document.querySelectorAll('a[href^="mailto:"]').forEach(a => {
          a.href = `mailto:${p.email}?subject=Inquiry%20from%20Portfolio`;
        });
      }
    }

    // C. Hydrate Typewriter Titles
    if (dynamicContent.typewriter && dynamicContent.typewriter.length > 0) {
      currentTypewriterTitles = dynamicContent.typewriter;
      const twEl = document.getElementById('typewriterText');
      if (twEl && currentTypewriterTitles[0]) {
        twEl.textContent = currentTypewriterTitles[0];
      }
    }

    // D. Hydrate 9 Core Services (3x3 Grid)
    if (dynamicContent.services && Array.isArray(dynamicContent.services)) {
      renderServices(dynamicContent.services);
    }

    // E. Hydrate 15 Web Projects
    if (dynamicContent.webProjects && Array.isArray(dynamicContent.webProjects)) {
      renderWebProjects(dynamicContent.webProjects);
    }

    // F. Hydrate Tech Arsenal
    renderTechArsenal();

    // G. Hydrate Experience & Roadmap
    renderRoadmap();

    // H. Hydrate Testimonials
    if (dynamicContent.testimonials && Array.isArray(dynamicContent.testimonials)) {
      renderTestimonials(dynamicContent.testimonials);
    }

    // Re-initialize dynamic spotlight listeners for newly inserted elements
    setTimeout(() => {
      initSpotlightCards();
      initScrollReveal();
    }, 50);

  } catch (err) {
    console.log('Error hydrating content:', err.message);
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/* ==========================================================================
   2. SEO & Tracking Metadata Hydration
   ========================================================================== */
function hydrateSeoMetadata(seo) {
  if (!seo) return;
  if (seo.pageTitle) document.title = seo.pageTitle;

  function setMetaTag(attr, val, content) {
    if (!content) return;
    let meta = document.querySelector(`meta[${attr}="${val}"]`);
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute(attr, val);
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', content);
  }

  setMetaTag('name', 'description', seo.metaDescription);
  setMetaTag('name', 'keywords', [seo.primaryKeyword, seo.secondaryKeywords, seo.metaKeywords].filter(Boolean).join(', '));
  setMetaTag('name', 'author', seo.author || 'Md. Shakibur Rahaman');
  setMetaTag('name', 'robots', seo.robots || 'index, follow, max-image-preview:large');
  if (seo.primaryKeyword) setMetaTag('name', 'primary-keyword', seo.primaryKeyword);
  if (seo.aiSeo?.aiSummary || seo.aiSummary) setMetaTag('name', 'ai-summary', seo.aiSeo?.aiSummary || seo.aiSummary);
  if (seo.aiSeo?.targetAiQueries || seo.targetAiQueries) setMetaTag('name', 'target-ai-queries', seo.aiSeo?.targetAiQueries || seo.targetAiQueries);

  if (seo.canonicalUrl) {
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', seo.canonicalUrl);
  }

  // Schema JSON-LD
  if (seo.schemaJson) {
    let schemaScript = document.getElementById('dynamic-schema-ld');
    if (!schemaScript) {
      schemaScript = document.createElement('script');
      schemaScript.id = 'dynamic-schema-ld';
      schemaScript.type = 'application/ld+json';
      document.head.appendChild(schemaScript);
    }
    schemaScript.textContent = typeof seo.schemaJson === 'object' ? JSON.stringify(seo.schemaJson) : seo.schemaJson;
  }
}

/* ==========================================================================
   3. Render 9 Core Services (3x3 Grid with Spotlight Hover)
   ========================================================================== */
function renderServices(services) {
  const container = document.getElementById('servicesContainer');
  if (!container) return;

  const defaultImages = {
    'branding': 'https://images.unsplash.com/photo-1634942537034-2531766767d1?auto=format&fit=crop&w=800&q=80',
    'graphics-design': 'https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=800&q=80',
    'web-development': 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80',
    'social-media-marketing': 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=800&q=80',
    'photoshoot-videography': 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=800&q=80',
    'event-activation': 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=800&q=80',
    'google-ads': 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80',
    'seo-aeo': 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=800&q=80',
    'public-relations': 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&w=800&q=80'
  };

  const html = services.map((svc) => {
    const deliverablesPreview = (svc.deliverables || []).slice(0, 3).map(item => `
      <li class="flex items-start gap-2 text-xs text-slate-300">
        <span class="w-1.5 h-1.5 rounded-full bg-[#00F59B] mt-1.5 shrink-0 shadow-sm shadow-[#00F59B]"></span>
        <span>${escapeHtml(item)}</span>
      </li>
    `).join('');

    const toolsHtml = (svc.tools || []).slice(0, 4).map(t => `
      <span class="px-2 py-0.5 rounded-md bg-white/[0.04] text-[10px] text-slate-300 border border-white/10 font-mono">${escapeHtml(t)}</span>
    `).join('');

    const slug = svc.slug || svc.id;
    const pageUrl = svc.pageUrl || `/services/${slug}.html`;
    const cardImg = svc.image || defaultImages[slug] || 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80';

    return `
      <a href="${pageUrl}" class="spotlight-card p-0 overflow-hidden flex flex-col justify-between group reveal-on-scroll cursor-pointer text-left no-underline block">
        <!-- Visual Picture Header -->
        <div class="relative h-48 w-full overflow-hidden bg-[#060911]">
          <img src="${escapeHtml(cardImg)}" alt="${escapeHtml(svc.title)}" class="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 filter brightness-90 contrast-105" loading="lazy">
          <div class="absolute inset-0 bg-gradient-to-t from-[#0D121F] via-[#0D121F]/40 to-transparent"></div>
          
          <!-- Top Floating Icon & Category Badge -->
          <div class="absolute top-3.5 left-3.5 w-10 h-10 rounded-xl bg-[#00F59B]/20 border border-[#00F59B]/40 backdrop-blur-md flex items-center justify-center text-[#00F59B] text-base shadow-lg shadow-black/60">
            <i class="fa-solid ${svc.icon || 'fa-layer-group'}"></i>
          </div>
          <div class="absolute top-3.5 right-3.5 px-3 py-1 rounded-full bg-black/80 backdrop-blur-md border border-white/10 text-[10.5px] font-mono font-bold text-[#00F59B]">
            ${escapeHtml(svc.badge || 'Core Pillar')}
          </div>
        </div>

        <div class="p-6 sm:p-7 flex-1 flex flex-col justify-between">
          <div>
            <!-- Title & Subtitle -->
            <h3 class="text-xl font-bold text-white group-hover:text-[#00F59B] transition-colors tracking-tight leading-snug">
              ${escapeHtml(svc.title)}
            </h3>
            <p class="text-xs text-slate-400 font-medium mt-1 mb-3">
              ${escapeHtml(svc.subtitle || '')}
            </p>

            <!-- Description -->
            <p class="text-xs text-slate-400 leading-relaxed mb-4 line-clamp-2">
              ${escapeHtml(svc.description)}
            </p>

            <!-- Deliverables Preview -->
            <div class="pt-3 border-t border-white/[0.08] mb-5">
              <div class="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 font-mono">Key Capabilities:</div>
              <ul class="space-y-1.5">
                ${deliverablesPreview}
              </ul>
            </div>
          </div>

          <!-- Card Footer -->
          <div>
            <div class="flex flex-wrap gap-1.5 mb-5">
              ${toolsHtml}
            </div>

            <div class="flex items-center justify-between pt-3 border-t border-white/[0.08]">
              <span class="text-xs font-bold text-white group-hover:text-[#00F59B] flex items-center gap-2 transition-colors">
                <span>Explore Dedicated Page</span>
                <i class="fa-solid fa-arrow-right text-[10px] group-hover:translate-x-1 transition-transform text-[#00F59B]"></i>
              </span>
              <span class="btn-circle-arrow" title="View Full Service Page">
                <i class="fa-solid fa-arrow-up-right-from-square"></i>
              </span>
            </div>
          </div>
        </div>
      </a>
    `;
  }).join('');

  container.innerHTML = html;
}

/* ==========================================================================
   4. Render 15 Web Projects Showcase Grid
   ========================================================================== */
function renderWebProjects(projects) {
  const container = document.getElementById('projectsGrid');
  if (!container) return;

  const html = projects.map(proj => {
    const displayUrl = proj.liveUrl.replace(/^https?:\/\//i, '').replace(/\/$/, '');

    return `
      <a href="${escapeHtml(proj.liveUrl)}" target="_blank" rel="noopener noreferrer" class="spotlight-card project-card flex flex-col group reveal-on-scroll cursor-pointer text-left no-underline block" data-category="${escapeHtml(proj.category || 'General')}">
        <!-- Browser Mockup Header -->
        <div class="browser-header">
          <div class="browser-dot"></div>
          <div class="browser-dot"></div>
          <div class="browser-dot"></div>
          <div class="browser-url-bar">${escapeHtml(displayUrl)}</div>
        </div>

        <!-- Image Preview Thumbnail -->
        <div class="project-thumbnail-wrapper">
          <img src="${escapeHtml(proj.previewImage)}" alt="${escapeHtml(proj.title)}" class="project-thumbnail" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80'">
          <div class="absolute inset-0 bg-gradient-to-t from-[#090D15] via-transparent to-transparent"></div>
          <div class="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/80 backdrop-blur-md border border-[#00F59B]/30 text-[10px] font-bold text-[#00F59B]">
            ${escapeHtml(proj.category)}
          </div>
        </div>

        <!-- Project Details Body -->
        <div class="p-5 sm:p-6 flex-1 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between gap-2 mb-2">
              <span class="text-[11px] text-[#00F59B] font-semibold uppercase tracking-wider font-mono">${escapeHtml(proj.client || 'Enterprise Web')}</span>
            </div>

            <h3 class="text-base sm:text-lg font-bold text-white mb-2 leading-snug font-display group-hover:text-[#00F59B] transition-colors">
              ${escapeHtml(proj.title)}
            </h3>

            <p class="text-xs text-slate-400 leading-relaxed mb-4">
              ${escapeHtml(proj.highlights || '')}
            </p>
          </div>

          <!-- Direct Live Website Button with Circular Arrow -->
          <div class="pt-3 border-t border-white/[0.08] flex items-center justify-between">
            <span class="text-xs font-bold text-white group-hover:text-[#00F59B] flex items-center gap-2 transition-colors">
              <span>${escapeHtml(proj.ctaText || 'Visit Live Website')}</span>
              <i class="fa-solid fa-arrow-up-right-from-square text-[10px] text-[#00F59B] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform"></i>
            </span>
            <span class="btn-circle-arrow" title="Visit Live Portal">
              <i class="fa-solid fa-arrow-up-right-from-square text-xs"></i>
            </span>
          </div>
        </div>
      </a>
    `;
  }).join('');

  container.innerHTML = html;
}

/* ==========================================================================
   5. Render Technologies & Tools Arsenal (Matching Reference Row)
   ========================================================================== */
function renderTechArsenal() {
  const container = document.getElementById('techArsenalGrid');
  if (!container) return;

  const stack = [
    { name: 'HTML5', icon: 'fa-brands fa-html5', color: '#E34F26' },
    { name: 'CSS3', icon: 'fa-brands fa-css3-alt', color: '#1572B6' },
    { name: 'JavaScript', icon: 'fa-brands fa-js', color: '#F7DF1E' },
    { name: 'TypeScript', icon: 'fa-solid fa-code', color: '#3178C6' },
    { name: 'React', icon: 'fa-brands fa-react', color: '#61DAFB' },
    { name: 'Next.js', icon: 'fa-solid fa-n', color: '#FFFFFF' },
    { name: 'Node.js', icon: 'fa-brands fa-node-js', color: '#339933' },
    { name: 'Express.js', icon: 'fa-solid fa-server', color: '#CBD5E1' },
    { name: 'MongoDB', icon: 'fa-solid fa-database', color: '#47A248' },
    { name: 'Tailwind CSS', icon: 'fa-solid fa-wind', color: '#38BDF8' },
    { name: 'Git', icon: 'fa-brands fa-git-alt', color: '#F05032' },
    { name: 'Docker', icon: 'fa-brands fa-docker', color: '#2496ED' },
    { name: 'Figma', icon: 'fa-brands fa-figma', color: '#F24E1E' },
    { name: 'Adobe Suite', icon: 'fa-solid fa-palette', color: '#FF0000' },
    { name: 'Google Ads', icon: 'fa-solid fa-chart-line', color: '#4285F4' },
    { name: 'GA4 / SEO', icon: 'fa-solid fa-magnifying-glass-chart', color: '#00F59B' }
  ];

  container.innerHTML = stack.map(tech => `
    <div class="tech-tile reveal-on-scroll">
      <i class="${tech.icon} tech-tile-icon" style="color: ${tech.color}"></i>
      <span class="tech-tile-name">${escapeHtml(tech.name)}</span>
    </div>
  `).join('');
}

/* ==========================================================================
   6. Render Experience & Roadmap Timeline
   ========================================================================== */
function renderRoadmap() {
  const container = document.getElementById('roadmapContainer');
  if (!container) return;

  const milestones = [
    { year: '2019', title: 'Agency Genesis', desc: 'Initiated independent design and front-end engineering for local enterprise and retail brands.', icon: 'fa-rocket' },
    { year: '2021', title: 'Creative Direction', desc: 'Scaled into 360° creative direction, comprehensive brand guidelines, and high-conversion e-commerce.', icon: 'fa-laptop-code' },
    { year: '2023', title: 'Enterprise Omnichannel', desc: 'Directed large-scale expo booth fabrication, national commercial video shoots, and performance marketing.', icon: 'fa-chart-pie' },
    { year: '2024 - Now', title: 'AI & AEO Architecture', desc: 'Spearheading modern web engineering, generative search engine optimization (AEO), and executive PR.', icon: 'fa-bullseye' }
  ];

  container.innerHTML = milestones.map(m => `
    <div class="roadmap-step text-center px-4 relative z-10 reveal-on-scroll">
      <div class="roadmap-node-circle">
        <i class="fa-solid ${m.icon}"></i>
      </div>
      <div class="inline-block px-3 py-1 rounded-full bg-white/[0.04] border border-[#00F59B]/30 text-[#00F59B] font-mono text-xs font-bold mb-2">
        ${escapeHtml(m.year)}
      </div>
      <h4 class="text-base font-bold text-white mb-1.5 font-display uppercase tracking-wider">${escapeHtml(m.title)}</h4>
      <p class="text-xs text-slate-400 leading-relaxed max-w-xs mx-auto">${escapeHtml(m.desc)}</p>
    </div>
  `).join('');
}

/* ==========================================================================
   7. Render Testimonials
   ========================================================================== */
function renderTestimonials(testimonials) {
  const container = document.getElementById('testimonialsContainer');
  if (!container) return;

  const html = testimonials.map(t => `
    <div class="spotlight-card p-6 sm:p-7 flex flex-col justify-between reveal-on-scroll">
      <div>
        <div class="quote-mark-green select-none">“</div>
        <p class="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
          ${escapeHtml(t.quote)}
        </p>
      </div>

      <div class="pt-5 border-t border-white/[0.08] flex items-center justify-between gap-3">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-full bg-[#00F59B] text-[#05070B] flex items-center justify-center font-bold text-sm shadow">
            ${escapeHtml((t.author || 'C').charAt(0))}
          </div>
          <div>
            <div class="text-xs sm:text-sm font-bold text-white">${escapeHtml(t.author)}</div>
            <div class="text-[11px] text-slate-400">${escapeHtml(t.organization)} • <span>${escapeHtml(t.role)}</span></div>
          </div>
        </div>
        <div class="star-rating-green">★★★★★</div>
      </div>
    </div>
  `).join('');

  container.innerHTML = html;
}

/* ==========================================================================
   8. Project Category Filter Bar Logic
   ========================================================================== */
function initProjectFilter() {
  const filterBtns = document.querySelectorAll('#projectFilterBar .filter-btn');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const targetCategory = btn.getAttribute('data-category') || 'all';
      filterProjectsByCategory(targetCategory);
    });
  });
}

function filterProjectsByCategory(category) {
  const projectCards = document.querySelectorAll('#projectsGrid .project-card');

  projectCards.forEach(card => {
    const cardCat = (card.getAttribute('data-category') || '').toLowerCase();
    const filterCat = category.toLowerCase();

    if (filterCat === 'all' || cardCat.includes(filterCat)) {
      card.style.display = 'flex';
      setTimeout(() => {
        card.style.opacity = '1';
        card.style.transform = 'scale(1)';
      }, 10);
    } else {
      card.style.opacity = '0';
      card.style.transform = 'scale(0.96)';
      setTimeout(() => {
        card.style.display = 'none';
      }, 200);
    }
  });
}

/* ==========================================================================
   9. Mouse Spotlight Sheen Effect on Cards
   ========================================================================== */
function initSpotlightCards() {
  const cards = document.querySelectorAll('.spotlight-card');

  cards.forEach(card => {
    card.removeEventListener('mousemove', handleCardMouseMove);
    card.addEventListener('mousemove', handleCardMouseMove, { passive: true });
  });
}

function handleCardMouseMove(e) {
  const rect = this.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;
  this.style.setProperty('--mouse-x', `${x}px`);
  this.style.setProperty('--mouse-y', `${y}px`);
}

/* ==========================================================================
   10. IntersectionObserver Scroll Reveal Engine
   ========================================================================== */
function initScrollReveal() {
  const reveals = document.querySelectorAll('.reveal-on-scroll, .reveal-fade-left, .reveal-fade-right');
  if (!('IntersectionObserver' in window)) {
    reveals.forEach(el => el.classList.add('revealed'));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
      }
    });
  }, {
    threshold: 0.12,
    rootMargin: '0px 0px -40px 0px'
  });

  reveals.forEach(el => observer.observe(el));
}

/* ==========================================================================
   11. Service Detail Modal Interactions
   ========================================================================== */
function initServiceModal() {
  const modal = document.getElementById('serviceModal');
  const closeBtn = document.getElementById('closeModalBtn');
  const requestQuoteBtn = document.getElementById('modalRequestQuoteBtn');

  if (!modal) return;

  function closeModal() {
    modal.classList.add('hidden');
    document.body.style.overflow = '';
  }

  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
      closeModal();
    }
  });

  if (requestQuoteBtn) {
    requestQuoteBtn.addEventListener('click', () => {
      closeModal();
      const contactSection = document.getElementById('contact');
      if (contactSection) {
        contactSection.scrollIntoView({ behavior: 'smooth' });
        if (currentModalService) {
          const serviceSelect = document.getElementById('leadService');
          if (serviceSelect) {
            serviceSelect.value = currentModalService.title;
          }
        }
      }
    });
  }

  window.openServiceModal = function(serviceId) {
    if (!dynamicContent || !dynamicContent.services) return;
    const svc = dynamicContent.services.find(s => s.id === serviceId);
    if (!svc) return;

    currentModalService = svc;

    const modalIcon = document.getElementById('modalIcon');
    const modalBadge = document.getElementById('modalBadge');
    const modalTitle = document.getElementById('modalTitle');
    const modalSubtitle = document.getElementById('modalSubtitle');
    const modalStats = document.getElementById('modalStats');
    const modalDesc = document.getElementById('modalDesc');
    const modalDeliverables = document.getElementById('modalDeliverables');
    const modalTools = document.getElementById('modalTools');
    const modalPageLink = document.getElementById('modalPageLink');

    if (modalIcon) modalIcon.className = `fa-solid ${svc.icon || 'fa-layer-group'} text-2xl text-[#00F59B]`;
    if (modalBadge) modalBadge.textContent = svc.badge || 'Core Vertical';
    if (modalTitle) modalTitle.textContent = svc.title;
    if (modalSubtitle) modalSubtitle.textContent = svc.subtitle || '';
    if (modalStats) modalStats.textContent = svc.stats || 'Verified Enterprise Impact';
    if (modalDesc) modalDesc.textContent = svc.description;

    if (modalDeliverables) {
      modalDeliverables.innerHTML = (svc.deliverables || []).map(d => `
        <li class="flex items-start gap-2.5 text-xs text-slate-300">
          <i class="fa-solid fa-check text-[#00F59B] mt-0.5 shrink-0"></i>
          <span>${escapeHtml(d)}</span>
        </li>
      `).join('');
    }

    if (modalTools) {
      modalTools.innerHTML = (svc.tools || []).map(t => `
        <span class="px-2.5 py-1 rounded-md bg-white/[0.04] text-xs text-slate-300 border border-white/10 font-mono">${escapeHtml(t)}</span>
      `).join('');
    }

    if (modalPageLink) {
      modalPageLink.href = svc.pageUrl || `/services/${svc.slug || svc.id}.html`;
    }

    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  };
}

/* ==========================================================================
   12. Contact Form Submission (Direct to /api/leads)
   ========================================================================== */
function initContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const submitBtn = document.getElementById('submitLeadBtn');
    const statusDiv = document.getElementById('formStatusAlert');
    const name = document.getElementById('leadName')?.value.trim();
    const email = document.getElementById('leadEmail')?.value.trim();
    const phone = document.getElementById('leadPhone')?.value.trim();
    const service = document.getElementById('leadService')?.value;
    const message = document.getElementById('leadMessage')?.value.trim();

    if (!name || !email || !message) {
      showFormStatus('Please complete all required fields.', 'error');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.innerHTML = `<span>Sending Brief...</span><i class="fa-solid fa-spinner fa-spin text-xs"></i>`;

    const leadPayload = {
      name,
      email,
      phone: phone || 'N/A',
      services: service || 'General Consultation',
      message,
      date: new Date().toISOString()
    };

    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(leadPayload)
      });

      const data = await res.json();
      if (res.ok && data.success) {
        showFormStatus(`✅ Thank you, ${name}! Your inquiry has been received. Shakibur will respond within 24 business hours.`, 'success');
        form.reset();
      } else {
        showFormStatus('Inquiry recorded. You may also connect directly via WhatsApp.', 'info');
      }
    } catch (err) {
      showFormStatus('Brief received. You can also connect via WhatsApp for immediate response.', 'info');
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = `<span>Send Message</span><i class="fa-solid fa-paper-plane text-xs"></i>`;
    }
  });

  function showFormStatus(msg, type) {
    const statusDiv = document.getElementById('formStatusAlert');
    if (!statusDiv) return;
    statusDiv.classList.remove('hidden');

    if (type === 'success') {
      statusDiv.className = 'p-4 rounded-xl text-xs font-semibold bg-[#00F59B]/10 text-[#00F59B] border border-[#00F59B]/30 block';
    } else {
      statusDiv.className = 'p-4 rounded-xl text-xs font-semibold bg-white/10 text-white border border-white/20 block';
    }
    statusDiv.textContent = msg;
  }
}

/* ==========================================================================
   13. Dynamic Rotating Typewriter Effect
   ========================================================================== */
function initTypewriter() {
  const target = document.getElementById('typewriterText');
  if (!target) return;

  let titleIndex = 0;
  let charIndex = 0;
  let isDeleting = false;
  let typingSpeed = 50;

  function type() {
    const titles = currentTypewriterTitles;
    if (!titles || titles.length === 0) return;

    const currentTitle = titles[titleIndex % titles.length];

    if (isDeleting) {
      target.textContent = currentTitle.substring(0, charIndex - 1);
      charIndex--;
      typingSpeed = 20;
    } else {
      target.textContent = currentTitle.substring(0, charIndex + 1);
      charIndex++;
      typingSpeed = 55;
    }

    if (!isDeleting && charIndex === currentTitle.length) {
      typingSpeed = 2400;
      isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      titleIndex = (titleIndex + 1) % titles.length;
      typingSpeed = 300;
    }

    setTimeout(type, typingSpeed);
  }

  type();
}

/* ==========================================================================
   14. Mobile Menu Navigation
   ========================================================================== */
function initMobileMenu() {
  const toggleBtn = document.getElementById('mobileMenuToggle');
  const menu = document.getElementById('mobileMenu');
  if (!toggleBtn || !menu) return;

  toggleBtn.addEventListener('click', () => {
    menu.classList.toggle('hidden');
  });

  document.querySelectorAll('.mobile-link').forEach(link => {
    link.addEventListener('click', () => {
      menu.classList.add('hidden');
    });
  });
}

/* ==========================================================================
   15. Scroll Effects: Active Navbar Item Tracking
   ========================================================================== */
function initScrollEffects() {
  const navbar = document.getElementById('navbar');
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.desktop-nav-link');

  function handleScroll() {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    if (navbar) {
      if (scrollTop > 40) {
        navbar.classList.add('shadow-2xl', 'bg-[#05070B]/95');
        navbar.classList.remove('bg-[#05070B]/80');
      } else {
        navbar.classList.remove('shadow-2xl', 'bg-[#05070B]/95');
        navbar.classList.add('bg-[#05070B]/80');
      }
    }

    let current = '';
    sections.forEach(sec => {
      const secTop = sec.offsetTop - 120;
      if (scrollTop >= secTop) {
        current = sec.getAttribute('id');
      }
    });

    navLinks.forEach(link => {
      link.classList.remove('text-[#00F59B]');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('text-[#00F59B]');
      }
    });
  }

  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();
}

/* ==========================================================================
   16. Scroll Reveal Motion Observer Engine
   ========================================================================== */
function initScrollReveal() {
  const elements = document.querySelectorAll('.reveal-on-scroll, .reveal-fade-left, .reveal-fade-right');
  if (!elements.length) return;

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    });

    elements.forEach(el => observer.observe(el));
  } else {
    // Fallback if IntersectionObserver is not supported
    elements.forEach(el => el.classList.add('revealed'));
  }
}

