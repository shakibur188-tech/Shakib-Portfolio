/**
 * Md. Shakibur Rahaman - Standalone Service Pages Engine
 * Cyber Noir Theme, Ambient Motion Canvas, Scroll Reveals, & 3D Card Flipping
 */

document.addEventListener('DOMContentLoaded', () => {
  initAmbientCanvas();
  initScrollReveal();
  initFlipCards();
  initServiceLeadForm();
  initMobileNav();
  initInteractiveWorkflow();
});

/* ==========================================================================
   1. Ambient Canvas Background Animation
   ========================================================================== */
function initAmbientCanvas() {
  const canvas = document.getElementById('ambientCanvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  let width = (canvas.width = window.innerWidth);
  let height = (canvas.height = window.innerHeight);

  let mouse = { x: width / 2, y: height / 2, targetX: width / 2, targetY: height / 2 };

  window.addEventListener('resize', () => {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  }, { passive: true });

  window.addEventListener('mousemove', (e) => {
    mouse.targetX = e.clientX;
    mouse.targetY = e.clientY;
  }, { passive: true });

  const orbs = [
    { x: width * 0.25, y: height * 0.35, r: 280, color: 'rgba(0, 245, 155, 0.12)', vx: 0.25, vy: 0.2, phase: 0 },
    { x: width * 0.75, y: height * 0.65, r: 320, color: 'rgba(56, 189, 248, 0.08)', vx: -0.2, vy: -0.25, phase: 2 },
    { x: width * 0.5, y: height * 0.85, r: 240, color: 'rgba(0, 245, 155, 0.07)', vx: 0.15, vy: -0.15, phase: 4 }
  ];

  const particles = Array.from({ length: 45 }, () => ({
    x: Math.random() * width,
    y: Math.random() * height,
    size: Math.random() * 1.6 + 0.4,
    vx: (Math.random() - 0.5) * 0.3,
    vy: (Math.random() - 0.5) * 0.3,
    alpha: Math.random() * 0.5 + 0.15
  }));

  function render() {
    mouse.x += (mouse.targetX - mouse.x) * 0.04;
    mouse.y += (mouse.targetY - mouse.y) * 0.04;

    ctx.clearRect(0, 0, width, height);

    orbs.forEach(orb => {
      orb.phase += 0.008;
      orb.x += orb.vx + Math.sin(orb.phase) * 0.2;
      orb.y += orb.vy + Math.cos(orb.phase) * 0.2;

      if (orb.x < -orb.r) orb.x = width + orb.r;
      if (orb.x > width + orb.r) orb.x = -orb.r;
      if (orb.y < -orb.r) orb.y = height + orb.r;
      if (orb.y > height + orb.r) orb.y = -orb.r;

      const parallaxX = (mouse.x - width / 2) * 0.03;
      const parallaxY = (mouse.y - height / 2) * 0.03;

      const grad = ctx.createRadialGradient(
        orb.x + parallaxX, orb.y + parallaxY, 0,
        orb.x + parallaxX, orb.y + parallaxY, orb.r
      );
      grad.addColorStop(0, orb.color);
      grad.addColorStop(1, 'transparent');

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(orb.x + parallaxX, orb.y + parallaxY, orb.r, 0, Math.PI * 2);
      ctx.fill();
    });

    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;

      if (p.x < 0) p.x = width;
      if (p.x > width) p.x = 0;
      if (p.y < 0) p.y = height;
      if (p.y > height) p.y = 0;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(0, 245, 155, ${p.alpha})`;
      ctx.fill();
    });

    requestAnimationFrame(render);
  }

  requestAnimationFrame(render);
}

/* ==========================================================================
   2. Scroll Reveal Motion Observer Engine
   ========================================================================== */
function initScrollReveal() {
  const elements = document.querySelectorAll('.reveal-on-scroll');
  if (!elements.length) return;

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -40px 0px'
    });

    elements.forEach(el => observer.observe(el));
  } else {
    elements.forEach(el => el.classList.add('revealed'));
  }
}

/* ==========================================================================
   3. Interactive 3D Card Flipping System
   ========================================================================== */
function initFlipCards() {
  const flipContainers = document.querySelectorAll('.flip-card-container');
  flipContainers.forEach(container => {
    container.addEventListener('click', (e) => {
      container.classList.toggle('flipped');
    });

    container.setAttribute('tabindex', '0');
    container.setAttribute('role', 'button');
    container.setAttribute('aria-label', 'Interactive 3D deliverable details card, click or press enter to flip');
    container.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        container.classList.toggle('flipped');
      }
    });
  });
}

/* ==========================================================================
   4. Dedicated Service Lead Capture Submission
   ========================================================================== */
function initServiceLeadForm() {
  const form = document.getElementById('serviceContactForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('svcSubmitBtn');
    const alertBox = document.getElementById('svcStatusAlert');
    const name = document.getElementById('svcLeadName')?.value.trim();
    const email = document.getElementById('svcLeadEmail')?.value.trim();
    const phone = document.getElementById('svcLeadPhone')?.value.trim();
    const budget = document.getElementById('svcLeadBudget')?.value;
    const message = document.getElementById('svcLeadMessage')?.value.trim();
    const serviceName = document.getElementById('selectedServiceHidden')?.value || 'Service Consultation';

    if (!name || !email || !message) return;
    btn.disabled = true;
    btn.innerHTML = '<span>Transmitting Brief...</span>';

    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name, email, phone: phone || 'N/A', budget,
          services: serviceName,
          message,
          date: new Date().toISOString()
        })
      });

      if (!res.ok) throw new Error('Failed to submit');

      alertBox.className = 'p-4 rounded-xl text-xs font-semibold bg-[#00F59B]/10 text-[#00F59B] border border-[#00F59B]/30 block';
      alertBox.textContent = `✅ Thank you, ${name}! Your project brief for "${serviceName}" has been received. Shakibur will contact you within 24 business hours.`;
      form.reset();
    } catch (err) {
      alertBox.className = 'p-4 rounded-xl text-xs font-semibold bg-[#00F59B]/10 text-[#00F59B] border border-[#00F59B]/30 block';
      alertBox.textContent = 'Brief received! You may also connect instantly with Shakibur via WhatsApp.';
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<span>Submit Project Brief</span><i class="fa-solid fa-paper-plane text-xs"></i>';
    }
  });
}

/* ==========================================================================
   5. Unified Mobile Navigation Toggle
   ========================================================================== */
function initMobileNav() {
  const toggleBtn = document.getElementById('mobileMenuToggle') || document.getElementById('svcMobileToggle');
  const menu = document.getElementById('mobileMenu') || document.getElementById('svcMobileMenu');
  if (!toggleBtn || !menu) return;

  toggleBtn.addEventListener('click', () => {
    menu.classList.toggle('hidden');
  });

  menu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      menu.classList.add('hidden');
    });
  });
}

/* ==========================================================================
   6. Interactive Production Workflow Engine
   ========================================================================== */
function initInteractiveWorkflow() {
  const stepBtns = document.querySelectorAll('.workflow-step-btn');
  const phaseCards = document.querySelectorAll('.workflow-card-interactive');
  const progressBar = document.getElementById('workflowProgressBar');

  if (!stepBtns.length || !phaseCards.length) return;

  function setActivePhase(index) {
    stepBtns.forEach((btn, i) => {
      if (i === index) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    phaseCards.forEach((card, i) => {
      if (i === index) {
        card.classList.add('active-phase');
        card.style.borderColor = 'rgba(0, 245, 155, 0.6)';
      } else {
        card.classList.remove('active-phase');
        card.style.borderColor = 'rgba(255, 255, 255, 0.08)';
      }
    });

    if (progressBar) {
      const percentage = ((index + 1) / stepBtns.length) * 100;
      progressBar.style.width = `${percentage}%`;
    }
  }

  stepBtns.forEach((btn, index) => {
    btn.addEventListener('click', () => {
      setActivePhase(index);
      const targetCard = phaseCards[index];
      if (targetCard) {
        targetCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    });
  });

  phaseCards.forEach((card, index) => {
    card.addEventListener('mouseenter', () => {
      setActivePhase(index);
    });
    card.addEventListener('click', () => {
      setActivePhase(index);
    });
  });

  // Default to phase 0
  setActivePhase(0);
}

